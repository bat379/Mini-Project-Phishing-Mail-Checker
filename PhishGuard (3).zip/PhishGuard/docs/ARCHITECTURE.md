# PhishGuard — System Architecture & Design Document

Educational, defensive cybersecurity awareness platform. No feature in this
document sends email, generates attack payloads, exploits vulnerabilities,
harvests credentials, or executes untrusted files. Every "scanner" below is
strictly read-only analysis of content the *user* already possesses or a
target the *user* explicitly chooses to inspect (e.g., checking their own
company's login page for a spoofed clone).

---

## 1. Folder Structure

```
PhishGuard/
├── main.py                        # entry point
├── config.py                      # runtime config (paths, feature flags, API key env vars)
├── requirements.txt
├── README.md
│
├── gui/
│   ├── app.py                     # root window, sidebar, frame router
│   ├── theme.py                   # colors, fonts, spacing tokens (single source of truth)
│   ├── dashboard.py
│   ├── email_analyzer_tab.py
│   ├── url_analyzer_tab.py
│   ├── website_scanner_tab.py
│   ├── password_checker_tab.py
│   ├── qr_analyzer_tab.py
│   ├── file_analyzer_tab.py
│   ├── education_tab.py
│   ├── quiz_tab.py
│   ├── ai_assistant_tab.py
│   ├── reports_tab.py
│   ├── history_tab.py
│   ├── settings_tab.py
│   ├── hackerzone_tab.py
│   └── widgets/                   # reusable: stat_card.py, risk_badge.py, chart_panel.py, toast.py
│
├── analyzer/                      # pure logic, no GUI imports, unit-testable in isolation
│   ├── email_parser.py            # .eml / raw text -> Email dataclass
│   ├── header_analyzer.py         # SPF/DKIM/DMARC awareness, Reply-To mismatch
│   ├── content_analyzer.py        # social-engineering language detection (built)
│   ├── link_checker.py            # structural URL red flags (built pattern, extended below)
│   ├── url_analyzer.py            # SSL cert check, WHOIS age, redirect chain, reputation score
│   ├── website_scanner.py         # cert validity, login-form detection, iframe/JS obfuscation heuristics
│   ├── password_analyzer.py       # entropy + crack-time estimate (zxcvbn-backed)
│   ├── qr_analyzer.py             # decode QR -> extract embedded URL -> reuse url_analyzer
│   ├── file_analyzer.py           # PDF/DOCX/ZIP/EXE *metadata only*, never opens/executes
│   └── risk_engine.py             # combines all analyzer outputs into one weighted score
│
├── threat_intel/                  # optional, opt-in, API-key gated
│   ├── base_provider.py           # abstract interface every provider implements
│   ├── virustotal_provider.py
│   ├── phishtank_provider.py
│   ├── abuseipdb_provider.py
│   └── provider_manager.py        # fan-out queries, merge results, graceful offline fallback
│
├── ai_assistant/
│   ├── assistant_client.py        # wraps Anthropic API call, user supplies their own key
│   └── prompts.py                 # system prompt scoping the assistant to cybersecurity education
│
├── education/
│   ├── content/                   # one JSON/Markdown file per topic (networking, linux, phishing,
│   │                               #   malware, cryptography, owasp_top10, wireshark, nmap, burpsuite)
│   ├── quiz_engine.py
│   ├── progress_tracker.py
│   ├── badges.py
│   ├── certificate_generator.py   # PDF certificate via reportlab
│   └── phishing_examples.py       # built — generic, non-branded quiz items
│
├── database/
│   ├── database.py                # connection + schema management (built, extended below)
│   ├── models.py                  # dataclasses mirroring each table
│   └── migrations/                # numbered .sql files for incremental schema changes
│
├── reports/
│   ├── pdf_report.py
│   └── csv_export.py
│
├── plugins/
│   ├── plugin_base.py             # ABC every third-party scanner plugin must implement
│   └── plugin_loader.py           # discovers plugins/*/plugin.py, validates interface, registers
│
├── utils/
│   ├── logger.py                  # built
│   ├── validators.py              # built, extended below
│   ├── network_utils.py           # timeouts, retries, SSRF-safe request wrapper
│   ├── crypto_utils.py            # entropy calculations for password module
│   └── search.py                  # unified search across education content + scan history
│
├── assets/                        # icons, fonts, badge images
├── tests/
│   ├── unit/                      # one file per analyzer module, no GUI, no network (mocked)
│   └── integration/               # GUI smoke tests, DB round-trip tests
└── logs/
```

---

## 2. System Architecture (text diagram)

```
┌───────────────────────────────────────────────────────────────────────┐
│                          PRESENTATION LAYER                            │
│   gui/app.py (sidebar + router)                                        │
│   ├─ Dashboard   ├─ Email Analyzer   ├─ URL Analyzer   ├─ Website Scan │
│   ├─ Password    ├─ QR Analyzer      ├─ File Analyzer  ├─ Education    │
│   ├─ AI Assistant├─ Reports          ├─ History         ├─ Settings    │
└───────────────────────────┬─────────────────────────────────────────┘
                              │  calls (no GUI logic below this line)
┌───────────────────────────▼─────────────────────────────────────────┐
│                        APPLICATION / CONTROLLER LAYER                  │
│   One thin controller per tab: takes GUI input, calls analyzer/,       │
│   formats results for display, writes to database/.                    │
└─────┬───────────────┬───────────────┬───────────────┬─────────────┬──┘
      │               │               │               │             │
┌─────▼─────┐  ┌──────▼──────┐ ┌──────▼──────┐ ┌──────▼─────┐ ┌────▼─────┐
│ analyzer/ │  │ threat_intel/│ │ education/  │ │ai_assistant│ │ plugins/ │
│ (pure,    │  │ (optional,   │ │ (content +  │ │ (optional, │ │ (future  │
│  offline, │  │  API-key     │ │  quiz +     │ │  user-     │ │  scanner │
│  testable)│  │  gated)      │ │  progress)  │ │  supplied  │ │  modules)│
└─────┬─────┘  └──────┬──────┘ └──────┬──────┘ │  key)      │ └────┬─────┘
      │               │               │        └──────┬─────┘      │
      └───────────────┴───────────────┴───────┬───────┴────────────┘
                                                │
                                     ┌──────────▼──────────┐
                                     │   database/ (SQLite) │
                                     │   local, single-file │
                                     └──────────────────────┘

Cross-cutting: utils/logger.py, utils/validators.py, config.py — used by every layer.
```

**Key architectural rule:** `analyzer/` never imports from `gui/`. This is what
makes the detection logic unit-testable and reusable (e.g., a future CLI
version could reuse 100% of `analyzer/` and `database/` with zero changes).

---

## 3. Database Schema

```sql
-- Core scan history (one row per analysis, any type)
CREATE TABLE analysis_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_type       TEXT NOT NULL,   -- 'email' | 'url' | 'website' | 'qr' | 'file' | 'password'
    target_label    TEXT NOT NULL,   -- filename, URL, or short description
    risk_score      INTEGER NOT NULL,
    risk_level      TEXT NOT NULL,   -- 'Low' | 'Medium' | 'High'
    findings_json   TEXT NOT NULL,   -- serialized list of findings (source of truth for reports)
    report_path     TEXT,
    analyzed_at     TEXT NOT NULL
);

-- Threat intel lookups, cached to avoid re-querying rate-limited APIs
CREATE TABLE threat_intel_cache (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    indicator       TEXT NOT NULL,   -- domain, URL, or IP
    provider        TEXT NOT NULL,   -- 'virustotal' | 'phishtank' | 'abuseipdb'
    result_json     TEXT NOT NULL,
    queried_at      TEXT NOT NULL,
    UNIQUE(indicator, provider)
);

-- Education progress
CREATE TABLE education_progress (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id        TEXT NOT NULL,   -- e.g. 'networking', 'owasp_top10'
    completed_units INTEGER DEFAULT 0,
    total_units     INTEGER NOT NULL,
    last_accessed   TEXT NOT NULL,
    UNIQUE(topic_id)
);

CREATE TABLE quiz_results (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id        TEXT NOT NULL,
    score            INTEGER NOT NULL,
    total_questions INTEGER NOT NULL,
    taken_at        TEXT NOT NULL
);

CREATE TABLE badges (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    badge_key       TEXT NOT NULL UNIQUE,  -- e.g. 'phishing_novice', 'owasp_master'
    earned_at       TEXT NOT NULL
);

CREATE TABLE certificates (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id        TEXT NOT NULL,
    certificate_path TEXT NOT NULL,
    issued_at       TEXT NOT NULL
);

-- App settings (key/value, single row per key)
CREATE TABLE settings (
    key             TEXT PRIMARY KEY,
    value           TEXT NOT NULL
);
```

`findings_json` intentionally stores structured data (not just a display
string) so `reports/pdf_report.py` and `history_tab.py` can both consume the
same source of truth without re-deriving it.

---

## 4. UI Wireframes (text form)

```
┌─────────────────────────────────────────────────────────────────┐
│ 🛡 PhishGuard                                          [🌙][⚙] │
├───────────┬─────────────────────────────────────────────────────┤
│ Dashboard │  Emails: 125   High: 8   Medium: 23   Low: 94        │
│ Email     │  ┌──────────────────┐  ┌───────────────────────────┐│
│ URL       │  │  Risk Pie Chart  │  │ Quick Scan                ││
│ Website   │  │                  │  │ [paste text.............] ││
│ Password  │  └──────────────────┘  │ [ Scan ]  results below   ││
│ QR        │                        └───────────────────────────┘│
│ Files     │  Recent Activity: (scrollable list, last 5 scans)   │
│ Education │                                                      │
│ AI Assist │                                                      │
│ Reports   │                                                      │
│ History   │                                                      │
│ Settings  │                                                      │
│ Hacker🕶️ │                                                      │
└───────────┴─────────────────────────────────────────────────────┘

Analyzer tab (email/url/website/file share this layout pattern):
┌─────────────────────────────────────────────────────────────────┐
│  [ Paste text ]  [ Upload file ]              Risk: ●●●○○ HIGH   │
│  ┌───────────────────────────┐  ┌───────────────────────────┐   │
│  │ Input panel                │  │ Findings (scrollable)     │   │
│  │                             │  │  ⚠ Sender mismatch  +20  │   │
│  │                             │  │  ⚠ Urgency language +15  │   │
│  └───────────────────────────┘  └───────────────────────────┘   │
│  [ Export PDF ]  [ Save to History ]                              │
└─────────────────────────────────────────────────────────────────┘

Education tab:
┌─────────────────────────────────────────────────────────────────┐
│  [Search topics.....................]                            │
│  ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐        │
│  │Networking │ │  Linux    │ │ Phishing  │ │  Malware  │  ...   │
│  │ ▓▓▓▓░ 80% │ │ ▓▓░░░ 40% │ │ ▓▓▓▓▓100% │ │ ░░░░░  0% │        │
│  └───────────┘ └───────────┘ └───────────┘ └───────────┘        │
│  Badges earned: 🏅🏅🏅          [ Take Quiz ]  [ View Certificate ]│
└─────────────────────────────────────────────────────────────────┘
```

---

## 5. Module-by-Module Implementation Plan

Build order (each step: explain concept → build → test → wait for go-ahead,
per our established workflow):

| # | Module | Depends on | Status |
|---|--------|-----------|--------|
| 1 | `analyzer/email_parser.py` | none | **building now** |
| 2 | `analyzer/header_analyzer.py` | email_parser | next |
| 3 | `analyzer/link_checker.py` (extend to `url_analyzer.py`) | none | next |
| 4 | `analyzer/risk_engine.py` | 1–3 + content_analyzer (built) | next |
| 5 | `gui/email_analyzer_tab.py` | 1–4 | next |
| 6 | `database/models.py` + schema migration for new tables | none | next |
| 7 | `analyzer/password_analyzer.py` (entropy + crack-time) | none | independent, easy win |
| 8 | `analyzer/qr_analyzer.py` | url_analyzer | after 3 |
| 9 | `analyzer/file_analyzer.py` (metadata-only) | none | independent |
| 10 | `analyzer/website_scanner.py` | url_analyzer | after 3 |
| 11 | `threat_intel/*` (optional, key-gated) | none | after core analyzers |
| 12 | `education/quiz_engine.py`, `progress_tracker.py`, `badges.py` | phishing_examples (built) | mid-priority |
| 13 | `education/certificate_generator.py` | quiz_engine | after 12 |
| 14 | `ai_assistant/assistant_client.py` | none | after core UX solid |
| 15 | `reports/pdf_report.py` | risk_engine | after 4 |
| 16 | `plugins/plugin_base.py` + loader | all core analyzers | last — extensibility layer |

---

## 6. Feature Roadmap with Priorities

**P0 — Core loop (ship first):** Email Analyzer end-to-end, Risk Engine,
Dashboard, History, basic PDF report. This alone is a usable product.

**P1 — Breadth:** URL Analyzer, Password Checker, File Analyzer (metadata),
Education Center content + quizzes.

**P2 — Depth:** Website Scanner, QR Analyzer, badges/certificates, search
across content + history.

**P3 — Optional/advanced:** Threat intel API integrations (require user's
own API keys, off by default), AI Assistant, plugin architecture for
third-party scanners.

Rationale: P0/P1 need no external services and no API keys, so the app is
fully usable offline before any optional integration is even touched.

---

## 7. Suggested Python Libraries

| Purpose | Library |
|---|---|
| GUI | `customtkinter` |
| Charts | `matplotlib` |
| HTML/DOM parsing (website scanner, email body) | `beautifulsoup4` |
| HTTP requests (user-initiated only) | `requests` |
| SSL certificate inspection | `ssl`, `socket` (stdlib) |
| WHOIS domain age | `python-whois` |
| DNS records (SPF/DKIM/DMARC awareness) | `dnspython` |
| Domain parsing | `tldextract` |
| PDF metadata/report generation | `pypdf` (read), `reportlab` (write) |
| DOCX metadata | `python-docx` |
| ZIP inspection | `zipfile` (stdlib) |
| Executable metadata (PE headers only, never runs the file) | `pefile` |
| QR decoding | `pyzbar` + `Pillow` |
| Password entropy / crack-time | `zxcvbn` |
| Data tables | `pandas` |
| Local storage | `sqlite3` (stdlib) |
| Testing | `pytest`, `pytest-mock` |
| Optional AI assistant | Anthropic API via `requests` or `anthropic` SDK, user-supplied key |

---

## 8. Security Best Practices

- **Never execute or open** analyzed files, attachments, or downloaded
  content — only parse metadata/structure.
- **SSRF-safe network layer**: `utils/network_utils.py` wraps all outbound
  requests with timeouts, redirect limits, and blocks requests to private/
  loopback IP ranges before fetching anything the user pastes.
- **API keys** (VirusTotal, PhishTank, AbuseIPDB, Anthropic) are read from
  environment variables or an encrypted local settings store — never
  hardcoded, never logged.
- **Local-only data**: SQLite file lives in the user's app-data directory;
  nothing is transmitted except explicit, opt-in threat-intel/API lookups.
- **Input caps**: every text/file analyzer enforces a max size before
  parsing (already applied in `content_analyzer.py`, extend to all).
- **Dependency hygiene**: pin versions in `requirements.txt`; run
  `pip-audit` periodically.
- **Least privilege**: file analyzer opens files in read-only mode, in
  isolated try/except blocks, never via `subprocess`/`os.system`.
- **Logging discipline**: never log full email bodies or full file contents
  at INFO level — log metadata (hashes, sizes, timestamps) only.

---

## 9. Testing Strategy

- **Unit tests** (`tests/unit/`): one file per `analyzer/*` module. All
  network/WHOIS/DNS calls mocked — these modules must be able to run fully
  offline in CI. Table-driven tests: known-phishing sample in, expected
  findings out.
- **Database tests**: round-trip insert/read against a temp SQLite file
  (pattern already validated for `database/database.py`).
- **Integration/smoke tests**: launch `App`, assert each tab's frame
  constructs without error (headless via `Xvfb` in CI on Linux).
- **Golden-file tests** for PDF/CSV report generation: generate, diff key
  fields (not byte-for-byte, since timestamps vary).
- **Manual QA checklist** per release: dark/light mode toggle, resize
  behavior, empty-state screens (0 history), large-input handling.

---

## 10. Code

Delivered module-by-module in chat, starting with `analyzer/email_parser.py`
below, following the same build → test → wait-for-go-ahead loop used so far.
