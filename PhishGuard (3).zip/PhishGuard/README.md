# PhishGuard
### Phishing Email Awareness & Analysis Toolkit

PhishGuard is a **defensive, educational** desktop application that teaches
students and security-awareness trainees how to recognize phishing emails
the way a real analyst does: by examining headers, sender metadata, links,
and language patterns — then scoring the risk and explaining *why* it
matters.

> ⚠️ **This project is strictly educational.** It does not send email,
> generate phishing content, harvest credentials, spoof senders, host fake
> login pages, or interact with real victims in any way. See
> [Security Limitations](#security-limitations) below.

---

## Educational Purpose Statement

PhishGuard was built for use in a **controlled classroom / lab environment**
to teach the fundamentals of email-based social engineering defense. Every
feature is *read-only and analytical*: a user pastes or uploads an email
they already possess (e.g., a suspicious message they personally received,
or a sample from a training corpus) and PhishGuard explains what in it is
suspicious and why. It does not automate any offensive activity.

---

## Features

- **Dashboard** — at-a-glance stats: emails analyzed, risk breakdown, awareness score
- **Email Analyzer** — paste raw email text or upload a `.eml` file
- **Header Analysis** — sender/Reply-To mismatch, SPF/DKIM/DMARC review
- **Social Engineering Detection** — flags urgency, fear, authority, reward, and trust-exploitation language patterns
- **Link Analysis** — inspects URLs *without visiting them* (domain patterns, IP-literal URLs, HTTPS usage, suspicious TLDs)
- **Attachment Awareness** — flags risky filenames/extensions from metadata only (never opens files)
- **Risk Scoring Engine** — weighted, explainable 0–100 score with Low/Medium/High bands
- **Education Center** — phishing types, attacker lifecycle, and staying-safe guidance
- **Reports** — exportable PDF/CSV summaries per analysis
- **History** — searchable local log of past analyses (SQLite)

---

## Requirements

- Windows 10/11
- Python 3.11+
- See `requirements.txt` for Python packages

## Installation

```bash
git clone <your-repo-url> PhishGuard
cd PhishGuard
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## Usage

1. Launch the app: `python main.py`
2. Go to **Email Analyzer** → paste email content or load a `.eml` file
3. Click **Analyze** to see header findings, social-engineering flags, link
   analysis, and an overall risk score
4. Visit **Education Center** to learn the concepts behind each finding
5. Export a report from the **Reports** tab; review past analyses in **History**

## Screenshots

*(placeholders — add screenshots as the UI is built)*

- `assets/screenshot_dashboard.png`
- `assets/screenshot_analyzer.png`
- `assets/screenshot_education.png`

---

## Architecture

```
PhishGuard/
├── main.py                 # App entry point
├── gui/                    # CustomTkinter views (one module per tab)
├── analyzer/                # Parsing & detection logic (pure, testable, no I/O side effects)
│   ├── email_parser.py      # .eml / raw text -> structured Email object
│   ├── header_analyzer.py   # SPF/DKIM/DMARC, Reply-To mismatch checks
│   ├── link_checker.py      # URL structural analysis (no network calls to the URL itself)
│   ├── content_analyzer.py  # Social-engineering language detection
│   └── risk_engine.py       # Combines findings into a weighted score
├── database/                 # SQLite persistence for analysis history
├── reports/                  # PDF (reportlab) and CSV export
├── education/                 # Static awareness content
└── utils/                     # Logging, input validation helpers
```

The `analyzer/` package has **no side effects** (no network calls, no file
execution) so it can be unit tested in isolation from the GUI.

---

## Security Limitations

By design, PhishGuard **does not**:

- Send, relay, or automate any email
- Generate ready-to-use phishing templates
- Collect, store, or transmit credentials
- Render or host fake/lookalike login pages
- Visit or fetch suspicious URLs automatically
- Open, execute, or unpack attachments
- Track, fingerprint, or target any recipient
- Spoof sender addresses or headers

It is a **static analysis and awareness tool only**. Any resemblance
between example content in the Education Center and real phishing emails is
for pattern recognition, not replication.

---

## Future Improvements

- Optional integration with reputation APIs (VirusTotal, urlscan.io) for
  domain-age / reputation lookups, gated behind explicit user opt-in
- Bulk `.eml` batch analysis mode
- Exportable "awareness quiz" mode for classroom use
- Multi-user history with role-based report access

---

## License / Disclaimer

For educational and internal security-awareness training use only.
